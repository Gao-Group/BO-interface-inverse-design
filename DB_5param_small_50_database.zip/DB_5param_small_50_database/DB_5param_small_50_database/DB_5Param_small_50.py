import numpy as np
import os
import time
import subprocess



def run_abaqus(param1, param2, param3, param4, param5, param6, abaqus_script):
    # Create the command to run Abaqus with a Python script
    command = f"abaqus cae noGUI={abaqus_script} -- {param1} {param2} {param3} {param4} {param5} {param6}"

    # Use subprocess to call the command
    process = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    if process.returncode != 0:
        print("Error running Abaqus:")
        print(process.stderr.decode())
    else:
        print("Abaqus ran successfully:")
        print(process.stdout.decode())



# generate random parameter values for the dataset.
# lower bound, upper bound, matrix size.
db_directory = r"/scratch/user/wei.zhang/Nacre_Project/Database_2D/DB_5param_small_50"
db_csv_name = "DB_5param_small_50.csv"
db_csv_path = os.path.join(db_directory, db_csv_name)

db_size = 50
num_para = 5
s = np.random.uniform((40, 40, 4, 4, 10),(120, 120, 8, 8, 40), (db_size, num_para))


good_index = []

if __name__ == '__main__':
    
    for i in range(db_size):
               
        # pass parameter values to ABAQUS scripts, and run ABAQUS
        abaqus_script = os.path.join(db_directory, "Nacre_2D_cae_txt.py")
        run_abaqus(i, s[i, 0], s[i, 1], s[i, 2], s[i, 3], s[i, 4], abaqus_script)
        
        job_name = 'Nacre_2D_db'
        txt_name = job_name + '_run' + str(i) + '.txt' 
        txt_path = os.path.join(db_directory, txt_name)
        if os.path.exists(txt_path):
            good_index.append(i)
            
    s = s[good_index, :]
    np.savetxt(db_csv_path, s, delimiter=',')
