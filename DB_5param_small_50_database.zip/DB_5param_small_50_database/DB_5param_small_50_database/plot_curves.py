# -*- coding: utf-8 -*-
"""
Created on Wed Dec 13 13:44:14 2023

@author: wei.zhang
"""

import numpy as np
import os
import matplotlib.pyplot as plt

# define parameters from ABAQUS model for stress and strain calculation
length = 8.4
thick = 1.0
area = length * thick

x_limit = 1.5
y_limit = 140


def extract_curve_txt(directory, txt_name):
    
    directory_txt =  os.path.join(directory, txt_name)       
    x = []
    y = []   
    file_hold = open(directory_txt, 'r')    
    for count, line in enumerate(file_hold):       
        if count < 4:
            pass        
        else:
            try:
                lines = [i for i in line.split()]
                x.append(float(lines[2])*100/length)   # in unit of %.
                y.append(float(lines[1])*10**6/area)     # in unit of MPa.
            except:
                pass
    x = np.array(x).reshape(-1, 1)
    y = np.array(y).reshape(-1, 1)
    curve = np.hstack((x, y))
    return curve



def plot_curve(curve, run_num):
    
    plt.figure()
    plt.plot(curve[:,0], curve[:,1])
    plt.xlabel('strains (%)')
    plt.ylabel('stress (MPa)')
    plt.xlim([0, x_limit])
    plt.ylim([0, y_limit])
    # plt.legend()
    plt.title(f"DB design {run_num}")
    plt.savefig(fname=f"DB design {run_num}")
    plt.close()
        
        
directory = r"C:/Users/wei.zhang/OneDrive - Texas A&M University/Research/Seed Grant MEEN/Cohesive Seam 2D/Dataset_2D/DB_5param_small_50_database"

for i in range(50):
    txt_name = f"Nacre_2D_db_run{i}.txt"
    curve = extract_curve_txt(directory, txt_name)
    plot_curve(curve, i)
    
    