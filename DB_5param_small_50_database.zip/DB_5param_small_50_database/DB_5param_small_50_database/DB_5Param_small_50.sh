#!/bin/bash

#SBATCH --job-name=DB_5Param_small_50
#SBATCH --time=47:00:00
#SBATCH --nodes=1 
#SBATCH --ntasks-per-node=2
#SBATCH --mem-per-cpu=2560M
#SBATCH --output=DB_5Param_small_50.out
#SBATCH --error=DB_5Param_small_50.err
#SBATCH --mail-type=END,FAIL
#SBATCH --mail-user=wei.zhang@tamu.edu

# Load the necessary modules
module purge
module load ABAQUS/2021

# Command to run your Python script
python DB_5Param_small_50.py