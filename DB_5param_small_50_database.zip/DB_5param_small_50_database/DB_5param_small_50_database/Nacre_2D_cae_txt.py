# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
import numpy as np
import os
import time
import sys


def Nacre_2D_cae(directory, cae_name, job_name, thick_ini, UY, Enn, G1, G2, stress_normal, stress_1st, stress_2nd, disp_f):
    
    import section
    import regionToolset
    import displayGroupMdbToolset as dgm
    import part
    import material
    import assembly
    import step
    import interaction
    import load
    import mesh
    import optimization
    import job
    import sketch
    import visualization
    import xyPlot
    import displayGroupOdbToolset as dgo
    import connectorBehavior
    
    os.chdir(directory)
    
    openMdb(pathName=os.path.join(directory, cae_name))

    mdb.models['Model-1'].Material(name='cohesive')
    mdb.models['Model-1'].materials['cohesive'].Elastic(type=TRACTION, table=((Enn, 
        G1, G2), ))
    mdb.models['Model-1'].materials['cohesive'].MaxsDamageInitiation(table=((stress_normal, 
        stress_1st, stress_2nd), ))
    mdb.models['Model-1'].materials['cohesive'].maxsDamageInitiation.DamageEvolution(
        type=DISPLACEMENT, table=((disp_f, ), ))

    mdb.models['Model-1'].CohesiveSection(name='interface', material='cohesive', 
        response=TRACTION_SEPARATION, initialThicknessType=SPECIFY, 
        initialThickness=thick_ini, outOfPlaneThickness=1.0)

    a = mdb.models['Model-1'].rootAssembly
    session.viewports['Viewport: 1'].setValues(displayedObject=a)
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='Step-1')
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(loads=ON, bcs=ON, 
        predefinedFields=ON, connectors=ON)
    mdb.models['Model-1'].boundaryConditions['UY'].setValues(u2= UY)

    mdb.Job(name=job_name, model='Model-1', description='', type=ANALYSIS, 
        atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=2, 
        memoryUnits=GIGA_BYTES, getMemoryFromAnalysis=True, 
        explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
        modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
        scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=2, 
        numDomains=2, numGPUs=0)
    
    mdb.jobs[job_name].submit(consistencyChecking=OFF)
    
    try:
        mdb.jobs[job_name].waitForCompletion(300)
    except (AbaqusException, message):
        print("Job timed out", message) 



def Nacre_2D_odb(cae_directory, db_directory, run_count, job_name):
    import section
    import regionToolset
    import displayGroupMdbToolset as dgm
    import part
    import material
    import assembly
    import step
    import interaction
    import load
    import mesh
    import optimization
    import job
    import sketch
    import visualization
    import xyPlot
    import displayGroupOdbToolset as dgo
    import connectorBehavior
    
    txt_name = job_name + '_run' + run_count + '.txt'
    txt_path = os.path.join(db_directory, txt_name)
    odb_path = os.path.join(cae_directory, job_name + '.odb')
    
    o3 = session.openOdb(name=odb_path)
    odb = session.odbs[odb_path]
    session.XYDataFromHistory(name='RF2 PI: PART-1-1 N: 4710 NSET RP-1', odb=odb, 
        outputVariableName='Reaction force: RF2 PI: PART-1-1 Node 4710 in NSET RP', 
        steps=('Step-1', ), __linkedVpName__='Viewport: 1')
    session.XYDataFromHistory(name='U2 PI: PART-1-1 N: 4710 NSET RP-1', odb=odb, 
        outputVariableName='Spatial displacement: U2 PI: PART-1-1 Node 4710 in NSET RP', 
        steps=('Step-1', ), __linkedVpName__='Viewport: 1')
    x0 = session.xyDataObjects['RF2 PI: PART-1-1 N: 4710 NSET RP-1']
    x1 = session.xyDataObjects['U2 PI: PART-1-1 N: 4710 NSET RP-1']
    session.writeXYReport(fileName=txt_path, xyData=(x0, x1))
    

iteration = sys.argv[-6]
sigma_c_n = float(sys.argv[-5])*1e-6 # this gets the third to last argument
sigma_c_s = float(sys.argv[-4])*1e-6 # this gets the third to last argument
delta_d_n = float(sys.argv[-3])*1e-3  # this gets the second to last argument
delta_d_s = float(sys.argv[-2])*1e-3  # this gets the second to last argument
delta_f = float(sys.argv[-1])*1e-3  # this gets the last argument

# define design variables. d for damage, f for final.
thick_ini = 0.025

if __name__ == '__main__':
                
    # the corresponding parameters in abaqus model
    Enn = sigma_c_n * thick_ini / delta_d_n
    G1 = sigma_c_s * thick_ini / delta_d_s
    G2 = G1
    
    stress_normal = sigma_c_n
    stress_1st = sigma_c_s
    stress_2nd = sigma_c_n
    
    disp_f = delta_f
    
    Enn = np.round(Enn, decimals=8)
    G1 = np.round(G1, decimals=8)
    G2 = np.round(G2, decimals=8)
    stress_normal = np.round(stress_normal, decimals=8)
    stress_1st = np.round(stress_1st, decimals=8)
    stress_2nd = np.round(stress_2nd, decimals=8)
    disp_f = np.round(disp_f, decimals=8)
    
    UY = 0.25
    
    job_name = 'Nacre_2D_db'
    cae_name = 'Nacre_2D_geo6.cae'
    directory = r"/scratch/user/wei.zhang/Nacre_Project/Database_2D/DB_5param_small_50"
    
    if os.path.exists(job_name + '.lck'):
        os.remove(job_name + '.lck')
    
    try:
        Nacre_2D_cae(directory, cae_name, job_name, thick_ini, UY, Enn, G1, G2, stress_normal, stress_1st, stress_2nd, disp_f)
        time.sleep(3)
        
        try:
            Nacre_2D_odb(directory, directory, str(iteration), job_name)
            time.sleep(5)
        except:
            print("the run of " + str(iteration) + " does not have odb file")
            pass
    
    except:
        print("the run of " + str(iteration) + " cannot submit cae file.")            
        pass